## Nombre: Pablo, Apellidos: Linari Perez , Titulación: DGIIM
## email: pablolinari@correo.ugr.es, DNI: 75571079W
extends MeshInstance3D
func ArrayMeshRejilla( m: int, n: int ) -> ArrayMesh:
	var meshrejilla = ArrayMesh.new()
	var pasox:float = float(1)/float(m-1)
	var pasoz:float = float(1)/float(n-1)
	
	var vertices = PackedVector3Array([])
	var triangulos =PackedInt32Array()
	var colores = PackedColorArray()
	var x = -pasox
	var z = -pasoz

	for i in range(m):
		x = x+pasox
		z = -pasoz
		for j in range(n):
			z= z+pasoz
			vertices.append(Vector3(x,0,z))
			colores.append(Color(x,0,z))
	
	for i in range((n*m)-n):
		if (i+1)%n ==0:
			pass
		else:
			triangulos.append(i)
			triangulos.append(i+n)
			triangulos.append(i+n+1)
			
			triangulos.append(i)
			triangulos.append(i+n+1)
			triangulos.append(i+1)
	
	var tablas = []
	tablas.resize(Mesh.ARRAY_MAX)
	tablas[Mesh.ARRAY_VERTEX] = vertices
	tablas[Mesh.ARRAY_INDEX] = triangulos     
	tablas[Mesh.ARRAY_COLOR]=colores


	meshrejilla.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, tablas)
		
	
	return meshrejilla

func _ready() -> void:
	mesh =ArrayMeshRejilla(10,10)
	var material = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	set_surface_override_material(0, material)
