## Nombre: Pablo, Apellidos:Linari Perez, Titulación:DGIIM
## email:pablolinari@correo.ugr.es, DNI :75571079W
extends MeshInstance3D

func _ready() -> void:
	var meshnueva = ArrayMesh.new()
	
	var vertices: PackedVector3Array = PackedVector3Array([])
	var vertices2d: PackedVector2Array = PackedVector2Array([
		Vector2(0,1),
		Vector2(1,0.5),
		Vector2(1,0)
		
	])
	

	var triangulos = PackedInt32Array([])
	Utilidades2.generarevolucion(vertices2d,12,vertices, triangulos)
	#Calcular normales USANDO LOS TRIÁNGULOS (no aristas)
	var normales : PackedVector3Array = Utilidades.calcNormales(vertices, triangulos)  # Asume función corregida
	
	# Arrays para el mesh
	var tablas = []
	tablas.resize(Mesh.ARRAY_MAX)
	tablas[Mesh.ARRAY_VERTEX] = vertices
	tablas[Mesh.ARRAY_INDEX] = triangulos  # Usa triángulos, no aristas
	tablas[Mesh.ARRAY_NORMAL] = normales   # Normales por vértice
	
	# Crear superficie con TRIÁNGULOS (para cubo sólido)
	meshnueva.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, tablas)
	
	# Asignar mesh
	mesh = meshnueva  # Usa 'mesh' en lugar de 'meshnueva' (asigna directamente)
	
	# Material (sin cambios, pero asegúrate de que use normales)
	var mat := StandardMaterial3D.new() 
	mat.albedo_color = Color.YELLOW
	mat.metallic = 0.3
	mat.roughness = 0.2
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	#mat.cull_mode =BaseMaterial3D.CULL_DISABLED
	material_override = mat
	
