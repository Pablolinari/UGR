## Nombre: Pablo, Apellidos:Linari Perez, Titulación:DGIIM
## email:pablolinari@correo.ugr.es, DNI :75571079W
extends MeshInstance3D

func _ready() -> void:
	var meshnueva = ArrayMesh.new()
	
	var vertices: PackedVector3Array = PackedVector3Array([])
	for s in range(0,3):
		for x in [0,1]:
			for y in [0,1]:
				for z in [0,1]:
					vertices.append(Vector3(x,y,z))
	

	var triangulos = PackedInt32Array([
			# Cara izq
			0,2,3,   0,3,1,
			# Cara frontal
			11,5,9,   11,7,5,
			# Cara derecha 
			15,6,4,  4,13,15,
			# Cara superior 
			10,14,23,  23,19,10,
			# Cara de atras 
			22,18,8,   8,12,22,
			# Cara de abajo
			16,17,21 , 21,20,16
		])
	# Calcular normales USANDO LOS TRIÁNGULOS (no aristas)
	var normales : PackedVector3Array = Utilidades.calcNormales(vertices, triangulos)  # Asume función corregida
	
	# Arrays para el mesh
	var tablas = []
	tablas.resize(Mesh.ARRAY_MAX)
	tablas[Mesh.ARRAY_VERTEX] = vertices
	tablas[Mesh.ARRAY_INDEX] = triangulos  # Usa triángulos, no aristas
	tablas[Mesh.ARRAY_NORMAL] = normales   # Normales por vértice
	
	# Crear superficie con TRIÁNGULOS (para cubo sólido)
	meshnueva.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, tablas)
	
	# Asignar mesh
	mesh = meshnueva  # Usa 'mesh' en lugar de 'meshnueva' (asigna directamente)
	
	# Material (sin cambios, pero asegúrate de que use normales)
	var mat := StandardMaterial3D.new() 
	mat.albedo_color = Color.YELLOW
	mat.metallic = 0.3
	mat.roughness = 0.2
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_PER_PIXEL
	#mat.cull_mode =BaseMaterial3D.CULL_DISABLED
	material_override = mat
