## Nombre: Pablo, Apellidos:Linari Perez, Titulación:DGIIM
## email:pablolinari@correo.ugr.es, DNI :75571079W
extends MeshInstance3D
@export var altura: float = 1.5



func _ready():
	mesh = crear_piramide_cubo()
	scale =Vector3(1.3,1,1)
	var material = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	set_surface_override_material(0, material)
	
	
func crear_piramide_cubo() -> ArrayMesh:
	var meshcasa = ArrayMesh.new()
	var vertices =PackedVector3Array([])
	var colores =PackedColorArray([]) 
	for x in [0,1]:
		for y in [0,0.5]:
			for z in [0,1]:
				vertices.append(Vector3(x,y,z))
				colores.append(Color(x,y,z))
	vertices.append(Vector3(0,1,0.5))
	vertices.append(Vector3(1,1,0.5))
	colores.append(Color(0,1,0.5))
	colores.append(Color(1,1,0.5))
	
	var triangulos = PackedInt32Array([
			# Cara izq
			0,2,3,   0,3,1,
			# Cara frontal
			3,5,1,   3,7,5,
			# Cara derecha 
			7,6,4,  4,5,7,
			# Cara de atras 
			6,2,0,   0,4,6,
			#triangulofrntal
			7,9,6,
			#trianguloatras
			2,8,3,
			#tejado frontal
			3,9,7, 3,8,9,
			#tejado trasero 
			6,8,2, 6,9,8
		])
		
	var tablas = []
	tablas.resize(Mesh.ARRAY_MAX)
	tablas[Mesh.ARRAY_VERTEX] = vertices
	tablas[Mesh.ARRAY_INDEX] = triangulos     
	tablas[Mesh.ARRAY_COLOR]=colores
	meshcasa.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, tablas)	
	
	return meshcasa


# Añade triángulo y calcula normal automáticamente
func _add_triangulo(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, normal_override: Vector3 = Vector3.ZERO):
	var normal = normal_override
	if normal == Vector3.ZERO:
		normal = Plane(a, b, c).normal
	st.set_normal(normal)
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)
