## Nombre: Pablo, Apellidos: Linari Perez , Titulación: DGIIM
## email: pablolinari@correo.ugr.es, DNI: 75571079W
extends MeshInstance3D

func _ready() -> void:
	const n = 4
	var vertices = PackedVector3Array()
	var triangulos = PackedInt32Array()

	for y in range(n):
		vertices.append(Vector3(0,y,0))
		vertices.append(Vector3(1,y,0))
		vertices.append(Vector3(1,y,1))
		vertices.append(Vector3(0,y,1))
	
	for i in range(n-1):
		var base = i * 4 
		triangulos.append(base + 0); triangulos.append(base + 1); triangulos.append(base + 5)
		triangulos.append(base + 0); triangulos.append(base + 5); triangulos.append(base + 4)
		
		triangulos.append(base + 1); triangulos.append(base + 2); triangulos.append(base + 6)
		triangulos.append(base + 1); triangulos.append(base + 6); triangulos.append(base + 5)
		
		triangulos.append(base + 2); triangulos.append(base + 3); triangulos.append(base + 7)
		triangulos.append(base + 2); triangulos.append(base + 7); triangulos.append(base + 6)
		
		triangulos.append(base + 3); triangulos.append(base + 0); triangulos.append(base + 4)
		triangulos.append(base + 3); triangulos.append(base + 4); triangulos.append(base + 7)
		
	var meshtorre = ArrayMesh.new()
	var tablas = []
	tablas.resize(Mesh.ARRAY_MAX)
	tablas[Mesh.ARRAY_VERTEX] = vertices
	tablas[Mesh.ARRAY_INDEX] = triangulos     
	meshtorre.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, tablas)
	
	mesh =meshtorre
	var material = StandardMaterial3D.new()
	material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo = true
	#material.cull_mode=BaseMaterial3D.CULL_DISABLED
	set_surface_override_material(0, material)
