#!/bin/bash

echo "Ejecutando el programa"

./SumaVectores 1000